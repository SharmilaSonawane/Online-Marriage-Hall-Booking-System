<!DOCTYPE html>
<html>
<head>
<title>ONLINE WEDDDING BANQUET BOOKING SYSTEM</title>
<link rel="stylesheet" type="text/css" href="css/sty.css">
<style>
.maindiv{
  width:70%;
  height:450px;
  position:absolute;
  left: 50%;
  top: 90%;
  transform: translate(-50%,-90%);
  background-size: 100%;
  background-color: #fff;
  box-shadow: 1px 2px 10px white;
}

.container h2{
  font-size: 40px;
  margin-top: 7%;
color: #000;
font: courier;
}


.container p{
  font-size: 25px;
  margin-left: 10%;
  font: courier;
}

.container li{
  font-size: 20px;
  margin-left: 8%;
  font: courier;
}
</style>
</head>
<body>
<header>
    <div class="main">
	<div class="title">
		<i><h1>Marriage Hall Booking System</h1></i>
</div>
<nav>
<ul>
  <li><a href="index.php">HOME</a></li>
  <li class="active"><a href="#">ABOUT</a></li>
  <li><a href="all_halls.php">ALL HALLS</a></li>
  <li><a href="userlogin.php">USER LOGIN</a></li>
  <li><a href="adminlogin.php">ADMIN LOGIN</a></li>
  <li><a href="register.php">REGISTER</a></li>
</ul>
</nav>
</div>
<div class="maindiv">
  <div class="container">
 <center><h2>A project by TEIT Group Members:</h2></center><br><br><br>
 <i><p>we are the students of SNJB</p>
 <p>this project is made by us for college purpose</p></i><br><br>
<ol>
<p>
  <li>Sharmila Hiraman Sonawane<b> Phone No:</b>8766824371 <b>Email ID:</b>sonawanesharmila16@gmail.com</br></li>
<li>Urmila Eknath Shinde <b> phone No:</b>7218354807 <b>Email ID:</b>shindeurmila@gmail.com</br></li>
<li>Sonal Bhalerao<b>Phone No:</b>9503064228 <b>Email ID:</b>bhaleraosonal@gmail.com</br></li>
<li> Kajal Gholap<b>Phone No:</b>8788224057 <b>Email ID:</b>gholapkajal@gmail.com</p></li>
</ol>
</div>
</div>
</body>
</html>
