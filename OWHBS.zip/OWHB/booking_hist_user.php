<?php
session_start();
if ($_SESSION['user_name']==true) {
  $conn=mysqli_connect('localhost','root','','owh');
  $username1=$_SESSION['user_name'];
  if (isset($_REQUEST['end'])) {

    $b_id=$_REQUEST['b_id'];
    $h_id=$_REQUEST['h_id'];
    $expired="expired";
    mysqli_query($conn,"update b_halls set status='$expired' where b_id='$b_id'");
}



 ?>
<!DOCTYPE html>
<html>
<head>
<title>ONLINE WEDDDING BANQUET BOOKING SYSTEM</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
<style>
.wrapper{
  width:280px;
  height:500px;
  position:absolute;
  left: -1%;
  top: 109%;
  background: #DC143C;
  transform: translate(1%,-109%);
  background-size: 100%;
  box-shadow: 1px 2px 10px 5px #000;
  opacity: .9;
  animation: slider 50s infinite linear;
}

.wrapper ul{

  list-style-type: none;
}

.wrapper ul li{

margin-left:5px;
}

.wrapper ul li a
{
  border: 2px solid #333333;
  display: block;
  text-decoration: none;
  color:#fff;
  padding: 15px;
  text-align:center;
  line-height:42px;
  height:42px;
  280px;
}

.wrapper ul li a:hover{
  color: #fff;
  background-color: #333333;
}

.wrapper ul li.active a{
  background-color: #fff;
  color: #000;

}

table{
  width:70%;
  margin: auto;
  left: -15%;
  top: 10%;
  background: #DC143C;
  transform: translate(15%,-10%);
  border: 1px solid #000;
  border-collapse: collapse;
  text-align: center;
  font-size: 20px;
  table-layout: fixed;
  height: auto;
  color: #fff;
  margin-top: 50px;
}

table th{
  width:auto;
  margin: auto;
  border: 1px solid #DC143C;
  border-collapse: collapse;
  max-width: 100px;
  overflow: hidden;
  text-overflow: ellipsis;
  font-size: 20px;
  table-layout: fixed;
  background: #000;
  padding:  auto;
  color: #fff;
  margin-top: 50px;
  text-decoration: none;
}

table td{
  width:auto;
  margin: auto;
  border: 1px solid #000;
  border-collapse: collapse;
  max-width: 100px;
  overflow: hidden;
  text-overflow: ellipsis;
  font-size: 20px;
  table-layout: fixed;
  background: #DC143C;
  padding:  20px;
  color: #fff;
  margin-top: 50px;
  text-decoration: none;
}

table td.small{
  width:auto;
  margin: auto;
  border: 1px solid #000;
  border-collapse: collapse;
  max-width: 100px;
  overflow: hidden;
  text-overflow: ellipsis;
  font-size: 20px;
  table-layout: fixed;
  background: #DC143C;
  padding:  20px;
  color: #000;
  margin-top: 50px;
  text-decoration: none;
}


</style>
</head>
<body>
<header>
    <div class="main">
	<div class="title">
		<i><h1>Marriage Hall Booking System</h1></i>
</div>
<nav>

<ul>
<li><a href="homeaul.php">HOME</a></li>
<li><a href="aboutaul.php">ABOUT</a></li>
<li><a href="all_hallsaul.php">ALL HALLS</a></li>
<li class="active"><a href="userpanel.php">USER PANEL</a></li>
<li><a href="logout.php">LOGOUT</a></li>
</ul>
</nav>
</div>
<div class="wrapper">
  <ul>
  <li><a href="userpanel.php">USER PROFILE</a></li>
  <li><a href="viewbookings.php">VIEW BOOKINGS</a></li>
  <li><a href="update_user.php">UPDATE PROFILE</a></li>
  <li class="active"><a href="#">BOOKING HISTORY</a></li>
  <li><a href="feedback.php">FEEDBACK</a></li>
</ul>
</div>
<table>
  <tr>
      <th>Booking ID</th>
      <th>Hall ID</th>
      <th>User ID</th>
      <th>Booked Date</th>
      <th>Status</th>

  </tr>
<?php
$sql="SELECT b_id, h_id, username, booked_date, status FROM b_halls WHERE username='$username1'";
$result=mysqli_query($conn,$sql);
while ($row=mysqli_fetch_array($result)) {
echo "<tr>
<td>".$row['b_id']."</td>
<td>".$row['h_id']."</td>
<td>".$row['username']."</td>
<td>".$row['booked_date']."</td>
<td>".$row['status']."</td>";

?>
</tr><?php
}
  echo "</table>";
?>
</table>

</body>
</html>
<?php
}
else {
  header('location:index.php');
}
 ?>
