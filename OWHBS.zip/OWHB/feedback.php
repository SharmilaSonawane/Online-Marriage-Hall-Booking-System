<?php
session_start();
if ($_SESSION['user_name']==true) {
  $conn=mysqli_connect('localhost','root','','owh');
  $username1=$_SESSION['user_name'];
 ?>
<!DOCTYPE html>
<html>
<head>
<title>ONLINE WEDDDING BANQUET BOOKING SYSTEM</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
<style>
.wrapper{
  width:280px;
  height:500px;
  position:absolute;
  left: -1%;
  top: 109%;
  background: #DC143C;
  transform: translate(1%,-109%);
  background-size: 100%;
  box-shadow: 1px 2px 10px 5px #000;
  opacity: .9;
  animation: slider 50s infinite linear;
}

.wrapper ul{

  list-style-type: none;
}

.wrapper ul li{

margin-left:5px;
}

.wrapper ul li a
{
  border: 2px solid #333333;
  display: block;
  text-decoration: none;
  color:#fff;
  padding: 15px;
  text-align:center;
  line-height:42px;
  height:42px;
  280px;
}

.wrapper ul li a:hover{
  color: #fff;
  background-color: #333333;
}

.wrapper ul li.active a{
  background-color: #fff;
  color: #000;

}

table{
  width:70%;
  margin: auto;
  left: -15%;
  top: 10%;
  background: #DC143C;
  transform: translate(15%,-10%);
  border: 1px solid #000;
  border-collapse: collapse;
  text-align: center;
  font-size: 20px;
  table-layout: fixed;
  height: auto;
  color: #fff;
  margin-top: 50px;
}
td{
  width:auto;
  margin: auto;
  border: 1px solid #000;
  border-collapse: collapse;
  max-width: 100px;
  overflow: hidden;
  text-overflow: ellipsis;
  font-size: 20px;
  table-layout: fixed;
  background: #DC143C;
  padding:  20px;
  color: #fff;
  margin-top: 50px;
  text-decoration: none;
}

.loginbox{
  width:500px;
  height:450px;
  background:linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)),#000;
  color: #fff;
  top:90%;
  left:50%;
     border-radius: 24px;
  position: absolute;
  transform:translate(-50%,-90%);
  box-sizing: border-box;
  padding: 70px 30px;
}

h2{
  margin: 0;
  padding: 0 0 20px;
text-align: center;
font-size: 30px;
font-weight: 600;
text-transform: uppercase;
}

.loginbox p{
  margin: 0;
  padding: 0;
  font-weight: bold;

}

.loginbox input{
  width:100%;
  margin-bottom: 20px;


}

.loginbox textarea
{
  border:0;
   background: none;
   display: block;;
   margin:30px auto;
   font-size: 17px;
   text-align: center;
   border: 2px solid #DC143C;
   padding: 14px 10px;
   width: 200px;
   outline: none;
   height: 150px;
   color:#fff;
   border-radius: 12px;
   transition: 0.25s;
}

.loginbox textarea:focus{
  width: 280px;
  border-color: #2ecc71;
}

.loginbox input[type ="Submit"]{
  width: 30%;
  border:0;
  background: none;
  display: block;;
  margin:20px auto;
  text-align: center;
  border: 2px solid #DC143C;
  padding: 14px 40px;
  outline: none;
  color:white;
  border-radius: 24px;
  transition: 0.25s;
  cursor: pointer;
}

.loginbox input[type ="Submit"]:hover{
  background: #2ecc71;
  border: 2px solid #2ecc71;
}

</style>
</head>
<body>
<header>
    <div class="main">
	<div class="title">
		<i><h1>Marriage Hall Booking System</h1></i>
</div>
<nav>

<ul>
<li><a href="homeaul.php">HOME</a></li>
<li><a href="aboutaul.php">ABOUT</a></li>
<li><a href="all_hallsaul.php">ALL HALLS</a></li>
<li class="active"><a href="userpanel.php">USER PANEL</a></li>
<li><a href="logout.php">LOGOUT</a></li>
</ul>
</nav>
</div>
<div class="wrapper">
  <ul>
  <li><a href="userpanel.php">USER PROFILE</a></li>
  <li><a href="viewbookings.php">VIEW BOOKINGS</a></li>
  <li><a href="updateuser.php">UPDATE PROFILE</a></li>
  <li><a href="booking_hist_user.php">BOOKING HISTORY</a></li>
  <li class="active"><a href="feedback.php">FEEDBACK</a></li>
</ul>
</div>
<div class="loginbox">
    <h2>feedback</h2>
    <form action="" method="post">
      <textarea name="feed" placeholder="type feedback" value="" required></textarea>
      <input type="submit" name="submit" value="SUBMIT"><br>
  </form>
  </div>
</body>
</html>
<?php
if (isset($_POST['submit'])) {
  $user=$_SESSION['user_name'];
  $feed=$_POST['feed'];
  $sql1="INSERT INTO feedback(u_name, feedback) VALUES ('$user','$feed')";
  mysqli_query($conn,$sql1);
  echo "<center>Feedback submitted successfully</center>";
}
}

else {
  header('location:index.php');
}
 ?>
