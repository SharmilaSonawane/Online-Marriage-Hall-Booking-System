<?php
session_start();
if ($_SESSION['user_name']==true) {

 ?>
<!DOCTYPE html>
<html>
<head>
<title>ONLINE WEDDDING BANQUET BOOKING SYSTEM</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
<style>
.maindiv{
  width:70%;
  height:450px;
  position:absolute;
  left: 50%;
  top: 90%;
  transform: translate(-50%,-90%);
  background-image: url("css/img/d.jpg");
  background-size: 100%;
  box-shadow: 1px 2px 10px 5px #000;
  animation: slider 50s infinite linear;
}

@keyframes slider{
  0%{
    background-image: url("css/img/d.jpg");
    }
    35%{background-image: url("css/img/e.jpg");}

      75%{background-image: url("css/img/kk.jpg");}
}
</style>
</head>
<body>
<header>
    <div class="main">
	<div class="title">
		<i><h1>Marriage Hall Booking System</h1></i>
</div>
<nav>

<ul>
<li class="active"><a href="#">HOME</a></li>
<li><a href="aboutaul.php">ABOUT</a></li>
<li><a href="all_hallsaul.php">ALL HALLS</a></li>
<li><a href="userpanel.php">USER PANEL</a></li>
<li><a href="logout.php">LOGOUT</a></li>
</ul>

</nav>
<div class="maindiv">

</div>
</div>
</body>
</html>
<?php
}
else {
  header('location:index.php');
}
 ?>
