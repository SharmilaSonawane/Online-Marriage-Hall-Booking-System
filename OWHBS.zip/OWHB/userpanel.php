<?php
session_start();
if ($_SESSION['user_name']==true) {
  $conn=mysqli_connect('localhost','root','','owh');
  $username1=$_SESSION['user_name'];
  $sql="select * from user where u_name='$username1'";
  $result=mysqli_query($conn,$sql);

 ?>
<!DOCTYPE html>
<html>
<head>
<title>ONLINE WEDDDING BANQUET BOOKING SYSTEM</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
<style>
.wrapper{
  width:280px;
  height:500px;
  position:absolute;
  left: -1%;
  top: 109%;
  background: #DC143C;
  transform: translate(1%,-109%);
  background-size: 100%;
  box-shadow: 1px 2px 10px 5px #000;
  opacity: .9;
  animation: slider 50s infinite linear;
}

.wrapper ul{

  list-style-type: none;
}

.wrapper ul li{

margin-left:5px;
}

.wrapper ul li a
{
  border: 2px solid #333333;
  display: block;
  text-decoration: none;
  color:#fff;
  padding: 15px;
  text-align:center;
  line-height:42px;
  height:42px;
  280px;
}

.wrapper ul li a:hover{
  color: #fff;
  background-color: #333333;
}

.wrapper ul li.active a{
  background-color: #fff;
  color: #000;

}

table{
  width:70%;
  margin: auto;
  left: -15%;
  top: 10%;
  background: #DC143C;
  transform: translate(15%,-10%);
  border: 1px solid #000;
  border-collapse: collapse;
  text-align: center;
  font-size: 20px;
  table-layout: fixed;
  height: auto;
  color: #fff;
  margin-top: 50px;
}
table td{
  width:auto;
  margin: auto;
  border: 1px solid #000;
  border-collapse: collapse;
  max-width: 100px;
  overflow: hidden;
  text-overflow: ellipsis;
  font-size: 20px;
  table-layout: fixed;
  background: #DC143C;
  padding:  20px;
  color: #fff;
  margin-top: 50px;
  text-decoration: none;
}

table td.small{
  width: 190px;
  max-height: 380px;
  margin: auto;
  border-collapse: collapse;
  overflow: hidden;
  text-overflow: ellipsis;
  font-size: 20px;
  background: #DC143C;
  border: 2px solid #000;
  table-layout: fixed;
  padding: 4px 10px;color: #000000;
  margin-top: 50px;
  text-decoration: none;
}

h2{
color : #DC143C;
margin-top:20px;
margin-left:580px;
font-size: 30px;
}

</style>
</head>
<body>
<header>
    <div class="main">
	<div class="title">
		<i><h1>Marriage Hall Booking System</h1></i>
</div>
<nav>

<ul>
<li><a href="homeaul.php">HOME</a></li>
<li><a href="aboutaul.php">ABOUT</a></li>
<li><a href="all_hallsaul.php">ALL HALLS</a></li>
<li class="active"><a href="userpanel.php">USER PANEL</a></li>
<li><a href="logout.php">LOGOUT</a></li>
</ul>
</nav>
</div>
<div class="wrapper">
  <ul>
  <li class="active"><a href="#">USER PROFILE</a></li>
  <li><a href="viewbookings.php">VIEW BOOKINGS</a></li>
  <li><a href="update_user.php">UPDATE PROFILE</a></li>
  <li><a href="booking_hist_user.php">BOOKING HISTORY</a></li>
  <li><a href="feedback.php">FEEDBACK</a></li>
</ul>
</div>
<?php
echo "<h2><i>Welcome ".$username1."....!!!</i></h2>";
while ($row=mysqli_fetch_array($result)) {
 ?>

<table>
      <tr><td class="small">Name</td><td><?php echo $row['name'] ?></td></tr>
      <tr><td class="small">Mobile No</td><td><?php echo $row['mob_no'] ?></td></tr>
      <tr><td class="small">Email</td><td><?php echo $row['email'] ?></td></tr>
      <tr><td class="small">Address</td><td><?php echo $row['addr'] ?></td></tr>
      <tr><td class="small">Username</td><td><?php echo $row['u_name'] ?></td></tr>
      <tr><td class="small">Password</td><td><?php echo $row['pass'] ?></td></tr>
</table>
<?php
}
 ?>
</body>
</html>
<?php
}
else {
  header('location:index.php');
}
 ?>
